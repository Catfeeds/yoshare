<?php
namespace App\Libraries\WePay\Example;

interface ILogHandler
{
    public function write($msg);
}